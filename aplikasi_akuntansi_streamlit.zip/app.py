import streamlit as st

st.set_page_config(
    page_title="Aplikasi Akuntansi",
    layout="wide"
)

st.title("📊 Aplikasi Akuntansi Sederhana")
st.info("Gunakan menu di sidebar kiri untuk berpindah halaman")