import streamlit as st
import pandas as pd
from io import BytesIO

st.title("💾 Simpan ke Excel")

df = pd.DataFrame(st.session_state.get("data", []))

if df.empty:
    st.warning("Belum ada data untuk disimpan")
    st.stop()

buku_besar = df.groupby("Akun")[["Debit", "Kredit"]].sum().reset_index()

total_debit = df["Debit"].sum()
total_kredit = df["Kredit"].sum()
laba = total_kredit - total_debit

laba_rugi = pd.DataFrame({
    "Keterangan": ["Pendapatan", "Beban", "Laba / Rugi"],
    "Jumlah": [total_kredit, total_debit, laba]
})

neraca = pd.DataFrame({
    "Keterangan": ["Total Aset", "Total Kewajiban + Modal"],
    "Jumlah": [total_debit, total_kredit]
})

output = BytesIO()
with pd.ExcelWriter(output, engine="openpyxl") as writer:
    df.to_excel(writer, sheet_name="Jurnal Umum", index=False)
    buku_besar.to_excel(writer, sheet_name="Buku Besar", index=False)
    laba_rugi.to_excel(writer, sheet_name="Laba Rugi", index=False)
    neraca.to_excel(writer, sheet_name="Neraca", index=False)

output.seek(0)

st.download_button(
    label="📥 Download Laporan Excel",
    data=output,
    file_name="laporan_akuntansi.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)