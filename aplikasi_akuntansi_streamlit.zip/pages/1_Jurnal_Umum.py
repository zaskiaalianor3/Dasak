import streamlit as st
import pandas as pd

st.title("📘 Jurnal Umum")

if "data" not in st.session_state:
    st.session_state.data = []

with st.form("form_jurnal"):
    tanggal = st.date_input("Tanggal")
    akun = st.text_input("Nama Akun")
    debit = st.number_input("Debit", min_value=0.0)
    kredit = st.number_input("Kredit", min_value=0.0)
    simpan = st.form_submit_button("Simpan")

    if simpan:
        st.session_state.data.append({
            "Tanggal": tanggal,
            "Akun": akun,
            "Debit": debit,
            "Kredit": kredit
        })
        st.success("Transaksi berhasil disimpan")

df = pd.DataFrame(st.session_state.data)

st.subheader("📋 Data Jurnal")
if not df.empty:
    st.dataframe(df)
else:
    st.info("Belum ada transaksi")