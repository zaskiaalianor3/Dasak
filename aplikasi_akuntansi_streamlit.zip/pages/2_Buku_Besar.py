import streamlit as st
import pandas as pd

st.title("📗 Buku Besar")

df = pd.DataFrame(st.session_state.get("data", []))

if not df.empty:
    buku_besar = df.groupby("Akun")[["Debit", "Kredit"]].sum().reset_index()
    st.dataframe(buku_besar)
else:
    st.info("Belum ada data")