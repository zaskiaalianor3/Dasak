import streamlit as st
import pandas as pd

st.title("📙 Neraca")

df = pd.DataFrame(st.session_state.get("data", []))

if not df.empty:
    aset = df["Debit"].sum()
    kewajiban_modal = df["Kredit"].sum()

    neraca = pd.DataFrame({
        "Keterangan": ["Total Aset", "Total Kewajiban + Modal"],
        "Jumlah": [aset, kewajiban_modal]
    })

    st.table(neraca)
else:
    st.info("Belum ada data")